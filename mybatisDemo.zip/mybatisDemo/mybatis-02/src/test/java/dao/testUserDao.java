package dao;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import entity.User;
import utils.MyBatisUtils;

import java.util.List;

public class testUserDao {

    @Test
    public void test01(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper sqlSessionMapper = sqlSession.getMapper(userMapper.class);
        List<User> allUser = sqlSessionMapper.getAllUser();
        for (User user : allUser) {
            System.out.println(user);
        }
        sqlSession.close();

    }
}
