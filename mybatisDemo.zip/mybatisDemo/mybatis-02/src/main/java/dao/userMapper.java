package dao;

import entity.User;
import java.util.List;
/**
 *
 */
public interface userMapper {
    //查询全部用户
    public List<User> getAllUser();
    //根据id查询用户
    public User getUserById(int id);
    //insert
    public int addUser(User user);
    //update语句
    public  int updateUser(User user);
    //delete语句
    public int deleteUser(int id);
}
