package dao;

import entity.User;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class testUserDao {

    static Logger logger = Logger.getLogger(testUserDao.class);
    @Test
    public void test01(){
        logger.info("开始创建sqlSession");
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper sqlSessionMapper = sqlSession.getMapper(userMapper.class);
        logger.info("调用方法getAllUser");
        List<User> allUser = sqlSessionMapper.getAllUser();
        logger.info("打印");
        for (User user : allUser) {
            System.out.println(user);
        }
        logger.info("关闭sqlSessioin");
        sqlSession.close();
        logger.info("测试结束!");
    }


    @Test
    public void test02(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        logger.info("开始创建sqlSessioin");
        userMapper userMapper = sqlSession.getMapper(userMapper.class);
        Map<String,Integer> map = new HashMap<>();
        map.put("startIndex",0);
        map.put("pageSize",2);
        logger.info("查询方法");
        List<User> userList = userMapper.getUserByLimit(map);
        for (User user : userList) {
            System.out.println(user);
        }
        sqlSession.close();
        logger.info("程序结束");
    }

    /*
    测试使用rowBounds来进行分页操作
     */
    @Test
    public void test03(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        //创建sqlsession
        logger.info("创建sqlSession");
        RowBounds rowBounds = new RowBounds(0,2);
        //使用RowBounds使用select方法
        List<User> userList = sqlSession.selectList("dao.userMapper.getUserByRowBounds", null, rowBounds);
        for (User user : userList) {
            System.out.println(user);
        }

        sqlSession.close();
        logger.info("测试结束!");

    }
}
