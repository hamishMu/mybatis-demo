package dao;

import entity.User;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.HashMap;

public class UserDaoTest {

    /**
     * 一级缓存是默认开启。在sqlsession中有效，sqlSession关闭消失。
     * 一级缓存的清除策略
     * 1，LRU：谁最少使用，就先清理谁
     * 2.FIFO:先进入先出，按照队列的先后顺序，进行
     * 3.soft
     * 4.weak
     * 默认使用LRU
     * 2.怎么开启二级缓存呢，二级缓存的是全局的缓存
     */

    @Test
    public void testAche(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        UserMapper mapper2 = sqlSession.getMapper(UserMapper.class);
        User user = mapper.findUserById(1);
        System.out.println(user);
        HashMap map = new HashMap();
        map.put("pwd","12345");
        map.put("id","1");
        int i = mapper.updateUser(map);
        System.out.println("更新"+i+"条数据");
        System.out.println("=====================");
        User user2 = mapper.findUserById(1);
        System.out.println(user2);
        sqlSession.close();
    }

    @Test
    public void testAche2(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User user = mapper.findUserById(1);
        System.out.println(user);

        sqlSession.close();
    }
}
