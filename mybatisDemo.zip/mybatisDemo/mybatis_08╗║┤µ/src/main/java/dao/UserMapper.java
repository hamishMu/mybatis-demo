package dao;

import entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

public interface UserMapper {

    User findUserById(@Param("id") int id);

    int updateUser(Map map);
}
