import dao.userMapper;
import entity.User;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.List;
public class userDaoTest {


    @Test
    public void test(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper userMapper = sqlSession.getMapper(userMapper.class);
        List<User> userList = userMapper.getAllUser();
        for (User user : userList) {
            System.out.println(user);
        }
        sqlSession.close();
    }

    @Test
    public  void test02(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper userMapper = sqlSession.getMapper(userMapper.class);
        int i = userMapper.addUser(new User("jack", "taobaoma"));
        if(i>0){
            System.out.println("加入成功");
        }else {
            System.out.println("加入失败");
        }
    }

    //测试更新
    @Test
    public void test03(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper userMapper = sqlSession.getMapper(userMapper.class);
        userMapper.updateUser("jACKMA","TAOBAOALI",7);
    }

    @Test
    public void test04(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper mapper = sqlSession.getMapper(userMapper.class);
        mapper.deleteUserById(7);
    }
}
