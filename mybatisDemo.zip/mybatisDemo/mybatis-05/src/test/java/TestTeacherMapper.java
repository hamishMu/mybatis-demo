import dao.StudentMapper;
import dao.TeacherMapper;
import entity.Student;
import entity.Teacher;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.List;

public class TestTeacherMapper {


    @Test
    public void testTeacher(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        TeacherMapper mapper = sqlSession.getMapper(TeacherMapper.class);
        Teacher teacher = mapper.getTeacher(1);
        System.out.println(teacher.toString());
        sqlSession.close();
    }

    @Test
    public void  test_Teacher_Student(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        TeacherMapper mapper = sqlSession.getMapper(TeacherMapper.class);
        List<Teacher> teacherList = mapper.getStudent();
        System.out.println(teacherList.size());
        for (Teacher teacher : teacherList) {
            System.out.println(teacher);
        }
        sqlSession.close();
        }

    }
