import dao.userMapper;
import entity.User;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.List;

public class TestUserMapper {


    @Test
    public void test01(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        userMapper mapper = sqlSession.getMapper(userMapper.class);
        List<User> allUser = mapper.getAllUser();
        for (User user : allUser) {
            System.out.println(user.toString());
        }
        sqlSession.close();
    }

}
