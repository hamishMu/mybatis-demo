package dao;

import entity.User;
import org.apache.ibatis.annotations.*;
import java.util.List;

/**
 *
 */
public interface userMapper {
    //查询全部用户,使用注解
    @Select("select * from user")
    public List<User> getAllUser();

    //增加
//    其中myabatis中的属性值需要与user中的属性名一样。
    @Insert("insert into user(name,pwd) values(#{name},#{password})")
    int addUser(User user);

    //删除
    @Delete("delete from user where id =#{id}")
    int deleteUserById(int id);

    //更新
    @Update("update user set name=#{name},pwd=#{password} where id = #{id}")
    int updateUser(@Param("name") String name, @Param("password") String password, @Param("id") Integer id);
}
