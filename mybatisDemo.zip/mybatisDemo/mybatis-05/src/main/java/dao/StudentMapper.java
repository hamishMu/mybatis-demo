package dao;

import entity.Student;
import java.util.List;


public interface StudentMapper {

    //查询所有学生信息已经对应的老师信息
    //select s.sid,s.sname,t.name
    //from students s ,teacher t where s.t= t.id;id
    List<Student> allStudent();

//select sid,sname,name
//from students  join teacher t on students.tid = t.id;
    List<Student> getAllStudent();
}
