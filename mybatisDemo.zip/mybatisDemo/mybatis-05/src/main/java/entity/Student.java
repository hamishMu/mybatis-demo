package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 学生实体类
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    private int sid;
    private String sname;
    private int  tid;
    private Teacher teacher;
}
