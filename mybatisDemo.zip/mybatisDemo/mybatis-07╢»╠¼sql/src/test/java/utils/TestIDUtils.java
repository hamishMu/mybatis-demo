package utils;

import org.junit.Test;

import static utils.IDUtils.getid;

public class TestIDUtils {
    @Test
    public void test(){
        System.out.println(getid());
        System.out.println(getid());
        System.out.println(getid());
    }
}
