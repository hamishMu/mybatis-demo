package dao;

import entity.Blog;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static utils.IDUtils.getid;

public class TestBlog {

    @Test
    public void addBlog(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        BlogMapper mapper = sqlSession.getMapper(BlogMapper.class);
        Blog blog = new Blog();
        blog.setId(getid());
        blog.setAuthor("hamishmu");
        blog.setTitle("我要学好Java");
        blog.setCreateTime(new Date());
        blog.setViews(999);
        mapper.addBlog(blog);
        blog.setId(getid());
        blog.setAuthor("hamishmu");
        blog.setTitle("我要学好Mybatis");
        blog.setCreateTime(new Date());
        blog.setViews(999);
        mapper.addBlog(blog);
        blog.setId(getid());
        blog.setAuthor("狂神");
        blog.setTitle("我要学好SpringBoot");
        blog.setCreateTime(new Date());
        blog.setViews(999);
        mapper.addBlog(blog);
        blog.setId(getid());
        blog.setAuthor("狂神");
        blog.setTitle("我要学好微服务");
        blog.setCreateTime(new Date());
        blog.setViews(999);
        mapper.addBlog(blog);
        sqlSession.close();
    }

    @Test
    public  void testBlogIf(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        BlogMapper mapper = sqlSession.getMapper(BlogMapper.class);
        HashMap map = new HashMap();
        map.put("title","我要学好Java");
        //不传递参数,查询结果为4个，当传递参数为1个
        List<Blog> blogList = mapper.queryBlogIf(map);
        for (Blog blog : blogList) {
            System.out.println(blog);
        }
        sqlSession.close();
    }


    @Test
    public void testBlogChooseWhere(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        BlogMapper mapper = sqlSession.getMapper(BlogMapper.class);
        HashMap map = new HashMap();
        map.put("title","我要学好Java");
        List<Blog> blogList = mapper.queryBlogChoose(map);
        for (Blog blog : blogList) {
            System.out.println(blog);
        }

        sqlSession.close();
    }


    @Test
    public void testUpdateSet(){
        SqlSession sqlSession = MyBatisUtils.getSqlSession();
        BlogMapper mapper = sqlSession.getMapper(BlogMapper.class);
        Map map = new HashMap();
        map.put("author","Java狂神带你飞");
        map.put("id","484a4bd1b80844d2a932e5eafec42da3");
        mapper.updateBlog(map);

        sqlSession.close();
    }

}
