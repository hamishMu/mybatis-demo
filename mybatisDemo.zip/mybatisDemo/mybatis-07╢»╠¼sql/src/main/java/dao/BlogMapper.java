package dao;

import entity.Blog;
import org.apache.ibatis.annotations.Insert;

import java.util.List;
import java.util.Map;

public interface BlogMapper {

    @Insert("insert into blog(id,title,author,create_time,views) values(#{id},#{title},#{author},#{createTime},#{views})")
    int addBlog(Blog blog);

    //查询博客 ，if
    List<Blog> queryBlogIf(Map map);
    //查询博客，使用choose
    List<Blog> queryBlogChoose(Map map);

    //更新sql语句
    int updateBlog(Map map);

}
