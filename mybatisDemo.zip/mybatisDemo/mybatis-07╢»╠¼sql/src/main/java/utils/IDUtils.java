package utils;


import java.util.UUID;

public class IDUtils {

    //生成UUID，唯一ID
    public static String getid(){
        return UUID.randomUUID().toString().replace("-","");
    }

}

