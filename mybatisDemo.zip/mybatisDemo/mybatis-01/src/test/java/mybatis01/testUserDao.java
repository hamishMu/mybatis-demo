package mybatis01;

import dao.userDao;
import entity.User;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import utils.MyBatisUtils2;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class testUserDao {

    @Test
    public void test01(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        User user = sqlSession.selectOne("dao.userDao.getUserById",1);
        System.out.println(user);
        sqlSession.close();
    }

    @Test
    public void test02(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        //获取接口
        userDao userDao  =  sqlSession.getMapper(userDao.class);
        List<User> allUser = userDao.getAllUser();
        for (User user : allUser) {
            System.out.println(user);
        }
        sqlSession.close();
    }

    @Test
    public void test03(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        userDao userDao = sqlSession.getMapper(userDao.class);
        User user = new User();
        user.setName("张思");
        user.setPwd("123abcde");
        int i = userDao.addUser(user);
        if(i>0){
            System.out.println("插入成功!");
        }else {
            System.out.println("插入失败!");
        }
        //增删改必须提交事务,不然数据库不会生效
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void testUpdate(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();

        userDao userDao = sqlSession.getMapper(userDao.class);
        User user = new User();
        user.setId(5);
        user.setName("张思思儿");
        user.setPwd("abcdefg1234");
        int i = userDao.updateUser(user);
        if(i>0){
            System.out.println("修改成功!");
        }
        //增删改需要提交事务
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void test04(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        userDao userDao = sqlSession.getMapper(userDao.class);
        userDao.deleteUser(5);
        sqlSession.commit();
        sqlSession.close();
    }

//    增删改需要提交事务，不然不会生效.
    @Test
    public void test05(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        userDao userDao = sqlSession.getMapper(userDao.class);
        List<User> users = userDao.findUserByLike("wang");
        for (User user : users) {
            System.out.println(user);
        }
        sqlSession.close();
    }

    @Test
    public void testMultipleParameter(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        userDao mapper = sqlSession.getMapper(userDao.class);

        User user = mapper.findByMultipleParameter(new User("wangwu","345345"));
        System.out.println(user);
        sqlSession.close();
    }

    @Test
    public void testMap(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        userDao userDao = sqlSession.getMapper(userDao.class);
        Map<String,Object> userMap = new HashMap<>();
        userMap.put("name","wangwu");
        userMap.put("passwd","345345");
        User user = userDao.findByMapper(userMap);
        System.out.println(user);
        sqlSession.close();
    }
}
