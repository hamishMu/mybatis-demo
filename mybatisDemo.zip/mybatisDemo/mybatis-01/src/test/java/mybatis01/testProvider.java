package mybatis01;
import dao.ProviderMapper;
import entity.Provider;
import org.junit.Test;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import utils.MyBatisUtils;
import utils.MyBatisUtils2;

import java.io.IOException;
import java.io.InputStream;

/**
 *测试provider代码
 */

public class testProvider {

    @Test
    public void Test01(){
       //获取sqlSessionFactory
        MyBatisUtils myBatisUtils = new MyBatisUtils();
        SqlSessionFactory sqlSessionFactory = myBatisUtils.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //执行sql
        //第一种方法:sqlSession.getMapper()
        /*ProviderMapper mapper = sqlSession.getMapper(ProviderMapper.class);
        Provider provider = mapper.getProviderById(1);
        provider.toString();*/
        Provider provider = sqlSession.selectOne("dao.ProviderMapper.getProviderById",1);
        System.out.println(provider);
        sqlSession.close();

    }


    @Test
    public void test02(){
        SqlSession sqlSession = MyBatisUtils2.getSqlSession();
        //执行sql方式1，使用getMapper方法
//        ProviderMapper providerMapper = sqlSession.getMapper(ProviderMapper.class);
//        Provider provider = providerMapper.getProviderById(1);
        //方法二，
        Provider provider = sqlSession.selectOne("dao.ProviderMapper.getProviderById", 1);
        System.out.println(provider);
        //执行sql方式2,
        sqlSession.close();
    }
}
