import entity.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;


public class main {
    public static void main(String[] args) throws IOException {
        //读取全局配置文件mybatis-config.xml
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        //创建sqlSession对象
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> userList   = sqlSession.selectList("mybatis01.selectUser");
        for (User user:userList){
            System.out.print(user.getId() );
            System.out.print(user.getName() );
            System.out.println(user.getPwd() );
        }
        sqlSession.close();
    }
}
