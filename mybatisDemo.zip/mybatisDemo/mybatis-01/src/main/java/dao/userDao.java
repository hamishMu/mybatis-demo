package dao;

import entity.User;
import java.util.List;
import java.util.Map;

/**
 *
 */
public interface userDao {
    //查询全部用户
    public List<User> getAllUser();
    //根据id查询用户
    public User getUserById(int id);
    //insert
    public int addUser(User user);
    //update语句
    public  int updateUser(User user);
    //delete语句
    public int deleteUser(int id);
    //模糊查询
    public List<User> findUserByLike(String name);
    //多条件查询
    public User findByMultipleParameter(User user);
    //使用mapper来查询
    public User findByMapper(Map<String, Object> userMap);

}
