package dao;

import entity.Provider;

/**
 * Provider接口
 */
public interface ProviderMapper {

    public Provider getProviderById(int id);
}
